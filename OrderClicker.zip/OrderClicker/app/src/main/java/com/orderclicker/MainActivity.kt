package com.orderclicker

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONObject

class MainActivity : Activity() {

    private lateinit var web: WebView
    private lateinit var status: TextView
    private lateinit var minEt: EditText
    private lateinit var maxEt: EditText
    private lateinit var kwEt: EditText
    private lateinit var dryCb: CheckBox
    private lateinit var toggle: Button
    private lateinit var script: String
    private var running = false

    inner class Bridge {
        @JavascriptInterface
        fun log(msg: String) {
            runOnUiThread { status.text = msg }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        script = assets.open("clicker.js").bufferedReader().use { it.readText() }
        val prefs = getSharedPreferences("oc", Context.MODE_PRIVATE)
        val pad = (8 * resources.displayMetrics.density).toInt()

        fun field(hint: String, value: String, number: Boolean) = EditText(this).apply {
            this.hint = hint
            setText(value)
            setSingleLine()
            if (number) inputType = InputType.TYPE_CLASS_NUMBER
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }

        minEt = field("Min ETB", prefs.getString("min", "6000")!!, true)
        maxEt = field("Max ETB", prefs.getString("max", "10000")!!, true)
        kwEt = field("Button text contains (optional)", prefs.getString("kw", "")!!, false)
        dryCb = CheckBox(this).apply { text = "Dry run"; isChecked = true }
        toggle = Button(this).apply { text = "START" }
        status = TextView(this).apply {
            text = "Log in to Telegram, open the bot chat, then press START."
            setBackgroundColor(Color.parseColor("#EEEEEE"))
            setPadding(pad, pad, pad, pad)
        }

        val row1 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(minEt); addView(maxEt)
        }
        val row2 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(kwEt); addView(dryCb)
        }

        web = WebView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
            )
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            @Suppress("DEPRECATION")
            settings.databaseEnabled = true
            CookieManager.getInstance().setAcceptCookie(true)
            addJavascriptInterface(Bridge(), "Android")
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                    view: WebView, request: WebResourceRequest
                ): Boolean {
                    val host = request.url.host ?: return true
                    return !(host == "telegram.org" || host.endsWith(".telegram.org"))
                }

                override fun onPageFinished(view: WebView, url: String?) {
                    if (url != null && url.contains("telegram.org")) {
                        view.evaluateJavascript(script, null)
                        if (running) startJs()
                    }
                }
            }
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, 0)
            addView(row1); addView(row2); addView(toggle); addView(status); addView(web)
        }
        setContentView(root)

        toggle.setOnClickListener {
            running = !running
            if (running) {
                prefs.edit()
                    .putString("min", minEt.text.toString())
                    .putString("max", maxEt.text.toString())
                    .putString("kw", kwEt.text.toString())
                    .apply()
                startJs()
            } else {
                web.evaluateJavascript("window.__oc && window.__oc.stop()", null)
            }
            toggle.text = if (running) "STOP" else "START"
        }

        web.loadUrl("https://web.telegram.org/k/")
    }

    private fun startJs() {
        val min = minEt.text.toString().toDoubleOrNull() ?: 6000.0
        val max = maxEt.text.toString().toDoubleOrNull() ?: 10000.0
        val kw = JSONObject.quote(kwEt.text.toString())
        web.evaluateJavascript(
            "window.__oc && window.__oc.start($min,$max,$kw,${dryCb.isChecked})", null
        )
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
