(function () {
  if (window.__oc) return;

  var cfg = { min: 6000, max: 10000, kw: "", dry: true, on: false };
  // Inline buttons under bot messages (Telegram Web K and Web A)
  var BTN_SEL = ".reply-markup-button, .InlineButtons .Button, .inline-button";
  var MSG_SEL = ".bubble, .Message, .message";

  function say(m) {
    try { Android.log(m); } catch (e) {}
  }

  function parseAmount(t) {
    var m =
      t.match(/(\d[\d,]*(?:\.\d+)?)\s*(?:ETB|Birr|br\b)/i) ||
      t.match(/(?:ETB|Birr)\s*[:\-]?\s*(\d[\d,]*(?:\.\d+)?)/i) ||
      t.match(/(?:amount|price|total)\D{0,20}(\d[\d,]*(?:\.\d+)?)/i);
    if (!m) return null;
    var n = parseFloat(m[1].replace(/,/g, ""));
    return isNaN(n) ? null : n;
  }

  function fire(el) {
    ["mousedown", "mouseup", "click"].forEach(function (type) {
      el.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, view: window }));
    });
  }

  function pickButton(msg) {
    var btns = msg.querySelectorAll(BTN_SEL);
    if (!btns.length) return null;
    if (!cfg.kw) return btns[0];
    var kw = cfg.kw.toLowerCase();
    for (var i = 0; i < btns.length; i++) {
      if ((btns[i].textContent || "").toLowerCase().indexOf(kw) !== -1) return btns[i];
    }
    return null;
  }

  function scan() {
    if (!cfg.on) return;
    var btns = document.querySelectorAll(BTN_SEL);
    for (var i = 0; i < btns.length; i++) {
      var msg = btns[i].closest(MSG_SEL);
      if (!msg || msg.dataset.oc) continue;
      var amt = parseAmount(msg.innerText || "");
      if (amt === null) continue; // text may not be fully rendered yet
      msg.dataset.oc = "1";
      if (amt < cfg.min || amt > cfg.max) {
        say("Skipped order: " + amt + " ETB (outside range)");
        continue;
      }
      var target = pickButton(msg);
      if (!target) { say("In range (" + amt + ") but no matching button"); continue; }
      if (cfg.dry) {
        say("DRY RUN - would click order: " + amt + " ETB");
      } else {
        fire(target);
        say("CLICKED order: " + amt + " ETB at " + new Date().toLocaleTimeString());
      }
    }
  }

  var observer = new MutationObserver(scan);
  var timer = null;

  window.__oc = {
    start: function (min, max, kw, dry) {
      cfg.min = min; cfg.max = max; cfg.kw = kw || ""; cfg.dry = !!dry;
      // Ignore orders that are already on screen when you press START
      document.querySelectorAll(BTN_SEL).forEach(function (b) {
        var m = b.closest(MSG_SEL);
        if (m && !m.dataset.oc) m.dataset.oc = "old";
      });
      cfg.on = true;
      observer.disconnect();
      observer.observe(document.body, { childList: true, subtree: true, characterData: true });
      if (timer) clearInterval(timer);
      timer = setInterval(scan, 250); // safety net in case a mutation is missed
      say((cfg.dry ? "DRY RUN" : "LIVE") + ": watching for orders " + min + "-" + max + " ETB");
    },
    stop: function () {
      cfg.on = false;
      observer.disconnect();
      if (timer) { clearInterval(timer); timer = null; }
      say("Stopped");
    }
  };
})();
